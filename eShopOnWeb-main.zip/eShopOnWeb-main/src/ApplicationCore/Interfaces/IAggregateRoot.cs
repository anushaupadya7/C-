﻿namespace Microsoft.eShopWeb.ApplicationCore.Interfaces;

public interface IAggregateRoot
{ }
