"""
Code Migration Agent - Main Entry Point

Usage:
    python main.py "Migrate all React components to StencilJS"
    python main.py --interactive
    python main.py --run-and-fix
    python main.py --validate order-default
"""

import asyncio
import argparse
import sys
from pathlib import Path

from loguru import logger
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

from agent.agents import create_migration_agent, AgentConfig


def setup_logging(verbose: bool = False) -> None:
    """Configure logging."""
    log_level = "DEBUG" if verbose else "INFO"
    logger.remove()
    logger.add(
        sys.stderr,
        level=log_level,
        format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{message}</cyan>",
    )


async def run_interactive(agent):
    """Run the agent in interactive mode."""
    print("\n" + "=" * 60)
    print("CODE MIGRATION AGENT - Interactive Mode")
    print("=" * 60)
    print("Commands:")
    print("  - Type your migration tasks")
    print("  - 'run' or 'fix' - Build and fix errors")
    print("  - 'validate <component>' - Validate logic mapping")
    print("  - 'quit' or 'exit' - Stop")
    print("=" * 60 + "\n")

    while True:
        try:
            user_input = input("You: ").strip()

            if not user_input:
                continue

            if user_input.lower() in ["quit", "exit", "q"]:
                print("Goodbye!")
                break

            if user_input.lower() in ["run", "fix", "build"]:
                user_input = "Use the execution-agent to build the project, fix any errors, and start the dev server"

            if user_input.lower().startswith("validate "):
                component = user_input.split(" ", 1)[1]
                user_input = f"Use the logic-validator subagent to validate the generated code for component '{component}'. Check that all business logic from the source is correctly implemented."

            print("\nAgent: Thinking...\n")

            # Stream the response
            async for message in agent.stream_async(user_input):
                if hasattr(message, "content"):
                    print(f"Agent: {message.content}\n")

        except KeyboardInterrupt:
            print("\nGoodbye!")
            break
        except Exception as e:
            logger.error(f"Error: {e}")


async def run_task(agent, task: str):
    """Run a single task."""
    print("\n" + "=" * 60)
    print("CODE MIGRATION AGENT")
    print("=" * 60)
    print(f"Task: {task}\n")

    result = await agent.run_async(task)

    if "messages" in result:
        for msg in result["messages"]:
            if hasattr(msg, "content") and msg.content:
                print(f"\n{msg.content}")

    return result


async def run_and_fix(agent, output_path: str):
    """Run and fix the generated code."""
    print("\n" + "=" * 60)
    print("EXECUTION AGENT - Build & Fix")
    print("=" * 60)
    print(f"Output path: {output_path}\n")

    result = await agent.run_and_fix(output_path)

    if "messages" in result:
        for msg in result["messages"]:
            if hasattr(msg, "content") and msg.content:
                print(f"\n{msg.content}")

    return result


async def validate_logic(agent, component_name: str, output_path: str):
    """Validate logic mapping for a component."""
    print("\n" + "=" * 60)
    print("LOGIC VALIDATOR - Checking Business Logic")
    print("=" * 60)
    print(f"Component: {component_name}")
    print(f"Output path: {output_path}\n")

    result = await agent.validate_logic(component_name, output_path)

    if "messages" in result:
        for msg in result["messages"]:
            if hasattr(msg, "content") and msg.content:
                print(f"\n{msg.content}")

    return result


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Code Migration Agent - Migrate codebases to StencilJS",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run a migration task
  python main.py "Query the knowledge graph and list all components"

  # Interactive mode
  python main.py --interactive

  # Migrate Order.Sample codebase
  python main.py "Migrate the Order.Sample codebase to StencilJS"

  # Build, run and fix errors
  python main.py --run-and-fix

  # Build and fix with custom output path
  python main.py --run-and-fix --output ./my-stencil-app

  # Validate logic for a specific component
  python main.py --validate order-default

Environment Variables:
  NEO4J_URI             - Neo4j connection URI
  NEO4J_USERNAME        - Neo4j username
  NEO4J_PASSWORD        - Neo4j password
  AZURE_OPENAI_API_KEY  - Azure OpenAI API key
  AZURE_OPENAI_ENDPOINT - Azure OpenAI endpoint
  AZURE_SEARCH_ENDPOINT - Azure AI Search endpoint
  AZURE_SEARCH_KEY      - Azure AI Search API key
  OPENAI_API_KEY        - OpenAI API key (fallback)
        """,
    )

    parser.add_argument(
        "task",
        nargs="?",
        default=None,
        help="Migration task to execute",
    )

    parser.add_argument(
        "--interactive", "-i",
        action="store_true",
        help="Run in interactive mode",
    )

    parser.add_argument(
        "--run-and-fix", "-r",
        action="store_true",
        help="Build, run tests, and fix errors iteratively",
    )

    parser.add_argument(
        "--validate",
        metavar="COMPONENT",
        help="Validate logic mapping for a specific component",
    )

    parser.add_argument(
        "--output", "-o",
        default="./output",
        help="Output directory for generated code (default: ./output)",
    )

    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose logging",
    )

    parser.add_argument(
        "--thread-id", "-t",
        default="migration-001",
        help="Thread ID for checkpointing (default: migration-001)",
    )

    args = parser.parse_args()

    setup_logging(args.verbose)

    # Create configuration
    config = AgentConfig.from_env()
    config.thread_id = args.thread_id
    config.output_dir = args.output

    # Create agent
    logger.info("Initializing Migration Agent...")
    agent = create_migration_agent(config)

    if args.interactive:
        asyncio.run(run_interactive(agent))
    elif args.run_and_fix:
        asyncio.run(run_and_fix(agent, args.output))
    elif args.validate:
        asyncio.run(validate_logic(agent, args.validate, args.output))
    elif args.task:
        asyncio.run(run_task(agent, args.task))
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
