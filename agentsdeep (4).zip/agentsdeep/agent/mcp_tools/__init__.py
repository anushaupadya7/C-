"""
MCP Tools Module

Provides integration with various MCP (Model Context Protocol) servers:
- Neo4j Cypher: Execute Cypher queries against Neo4j
- Neo4j Memory: Knowledge graph and entity management
- Azure AI Search: Vector and semantic search
- Windows CLI: Shell command execution for running builds and dev servers
"""

from .neo4j_cypher_mcp import get_neo4j_cypher_mcp_tools, get_neo4j_cypher_mcp_config
from .neo4j_memory_mcp import get_neo4j_memory_mcp_tools, get_neo4j_memory_mcp_config
from .azure_search_mcp import (
    get_azure_search_mcp_tools,
    get_azure_search_sdk_tools,
    get_azure_search_config,
)
from .windows_cli_mcp import get_windows_cli_mcp_tools, get_windows_cli_mcp_config, configure_windows_cli

__all__ = [
    # Neo4j Cypher
    "get_neo4j_cypher_mcp_tools",
    "get_neo4j_cypher_mcp_config",
    # Neo4j Memory
    "get_neo4j_memory_mcp_tools",
    "get_neo4j_memory_mcp_config",
    # Azure Search
    "get_azure_search_mcp_tools",
    "get_azure_search_sdk_tools",
    "get_azure_search_config",
    # Windows CLI
    "get_windows_cli_mcp_tools",
    "get_windows_cli_mcp_config",
    "configure_windows_cli",
]
