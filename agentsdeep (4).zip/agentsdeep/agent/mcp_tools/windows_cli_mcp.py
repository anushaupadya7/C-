"""
Windows CLI MCP Tools

Loads tools from the Windows CLI MCP server for executing shell commands.
Used for running StencilJS development server, builds, and tests.

"""

import os
import asyncio
from typing import List, Optional
from pathlib import Path
from langchain_core.tools import BaseTool
from langchain_mcp_adapters.client import MultiServerMCPClient
from loguru import logger


def get_windows_cli_mcp_config(
    working_dir: Optional[str] = None,
    allowed_paths: Optional[List[str]] = None,
) -> dict:
    """
    Get MCP server configuration for Windows CLI server.

    Args:
        working_dir: Working directory for command execution
        allowed_paths: List of allowed paths for file operations

    This server provides shell command execution on Windows.
    """
    # Get the workspace directory - default to C:/
    if working_dir is None:
        working_dir = os.getenv(
            "AGENT_WORKING_DIR",
            "C:/"
        )

    # Ensure it's an absolute path
    working_dir = os.path.abspath(working_dir)

    # Default allowed paths include Order.Sample and output
    if allowed_paths is None:
        output_dir = os.getenv(
            "AGENT_OUTPUT_DIR",
            "C:/output"
        )
        output_dir = os.path.abspath(output_dir)

        allowed_paths = [
            working_dir,
            output_dir,
            "C:/",
            "C:/Order.Sample",
            "C:/output",
        ]

    # Remove duplicates and ensure all are absolute paths
    allowed_paths = list(set(os.path.abspath(p) for p in allowed_paths))

    logger.info(f"Windows CLI MCP config:")
    logger.info(f"  Working dir: {working_dir}")
    logger.info(f"  Allowed paths: {allowed_paths}")

    return {
        "everything": {
            "transport": "stdio",
            "command": "npx",
            "args": ["-y", "@modelcontextprotocol/server-everything"]
        },
              "shell-command": {
        "transport": "stdio",
      "command": "npx",
      "args": ["-y", "shell-command-mcp"],
      "env": {
        "ALLOWED_COMMANDS": "*"
      }
    }
  }    


# Global variable to store configured paths
_configured_working_dir: Optional[str] = None
_configured_allowed_paths: Optional[List[str]] = None


def configure_windows_cli(
    working_dir: str,
    allowed_paths: Optional[List[str]] = None,
) -> None:
    """
    Configure the Windows CLI MCP server paths.

    Call this before get_windows_cli_mcp_tools() to set custom paths.

    Args:
        working_dir: Working directory for command execution
        allowed_paths: List of allowed paths for file operations
    """
    global _configured_working_dir, _configured_allowed_paths
    _configured_working_dir = os.path.abspath(working_dir)
    if allowed_paths:
        _configured_allowed_paths = [os.path.abspath(p) for p in allowed_paths]
    logger.info(f"Configured Windows CLI: working_dir={_configured_working_dir}")


async def _load_windows_cli_tools() -> List[BaseTool]:
    """Async function to load tools from Windows CLI MCP server."""
    config = get_windows_cli_mcp_config(
        working_dir=_configured_working_dir,
        allowed_paths=_configured_allowed_paths,
    )

    logger.info("Connecting to Windows CLI MCP server...")

    try:
        client = MultiServerMCPClient(config)
        tools = await client.get_tools()
        logger.info(f"Loaded {len(tools)} tools from Windows CLI MCP")
        return tools
    except Exception as e:
        logger.error(f"Failed to load Windows CLI MCP tools: {e}")
        return []


def get_windows_cli_mcp_tools() -> List[BaseTool]:
    """
    Get Windows CLI MCP tools for use with LangChain agents.

    This function connects to the Windows CLI MCP server
    and returns LangChain-compatible tools for shell execution.

    Returns:
        List of LangChain BaseTool objects for CLI operations
    """
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(asyncio.run, _load_windows_cli_tools())
                return future.result()
        else:
            return loop.run_until_complete(_load_windows_cli_tools())
    except RuntimeError:
        return asyncio.run(_load_windows_cli_tools())


# List of expected tools from this MCP server
WINDOWS_CLI_TOOLS = [
    "run_command",      # Execute a shell command
    "run_powershell",   # Execute PowerShell command
]
