"""
Azure AI Search MCP Tools.

Loads tools from the Azure AI Search MCP server using langchain-mcp-adapters.
Based on: https://learn.microsoft.com/en-us/azure/developer/azure-mcp-server/tools/azure-ai-search

Tools provided by @azure/mcp-server-azure-ai-search:
- get_index_details: Retrieve index schema and field information
- query_index: Execute search queries (full-text, vector, hybrid)
- get_knowledge_base: Get knowledge base details
- retrieve_from_knowledge_base: Execute retrieval operations
"""

import os
import asyncio
from typing import List, Optional
from langchain_core.tools import BaseTool, tool
from loguru import logger

# Try to import MCP adapters
try:
    from langchain_mcp_adapters.client import MultiServerMCPClient
    MCP_AVAILABLE = True
except ImportError:
    MCP_AVAILABLE = False
    logger.warning("langchain-mcp-adapters not installed. MCP tools will not be available.")

# Try to import Azure Search SDK as fallback
try:
    from azure.search.documents import SearchClient
    from azure.search.documents.indexes import SearchIndexClient
    from azure.core.credentials import AzureKeyCredential
    AZURE_SDK_AVAILABLE = True
except ImportError:
    AZURE_SDK_AVAILABLE = False
    logger.warning("azure-search-documents not installed. Azure Search fallback will not be available.")


def get_azure_search_config():
    """
    Get Azure Search configuration from environment variables.

    Supports multiple naming conventions:
    - AZURE_SEARCH_ENDPOINT or AZURE_SEARCH_SERVICE_NAME
    - AZURE_SEARCH_KEY or AZURE_SEARCH_API_KEY
    - AZURE_SEARCH_INDEX_NAME
    """
    # Support both endpoint URL and service name
    endpoint = os.getenv("AZURE_SEARCH_ENDPOINT", "")
    service_name = os.getenv("AZURE_SEARCH_SERVICE_NAME", "")

    # Support both KEY and API_KEY
    api_key = os.getenv("AZURE_SEARCH_KEY", "") or os.getenv("AZURE_SEARCH_API_KEY", "")

    # Index name
    index_name = os.getenv("AZURE_SEARCH_INDEX_NAME", "code-index")

    # Determine effective endpoint
    if endpoint:
        effective_endpoint = endpoint
        # Extract service name from endpoint for MCP
        if ".search.windows.net" in endpoint:
            service_name = endpoint.replace("https://", "").replace(".search.windows.net", "")
    elif service_name:
        effective_endpoint = f"https://{service_name}.search.windows.net"
    else:
        effective_endpoint = ""

    return {
        "endpoint": effective_endpoint,
        "service_name": service_name,
        "api_key": api_key,
        "index_name": index_name,
        "is_configured": bool(effective_endpoint and api_key),
    }


def get_azure_search_mcp_config() -> dict:
    """
    Get MCP server configuration for Azure AI Search server.

    Environment variables (supports multiple naming conventions):
    - AZURE_SEARCH_ENDPOINT or AZURE_SEARCH_SERVICE_NAME
    - AZURE_SEARCH_KEY or AZURE_SEARCH_API_KEY
    - AZURE_SEARCH_INDEX_NAME
    """
    config = get_azure_search_config()

    if not config["is_configured"]:
        logger.warning("Azure AI Search credentials not configured")
        return {}

    return {
        "azure-ai-search": {
            "command": "npx",
            "args": ["-y", "@azure/mcp-server-azure-ai-search"],
            "transport": "stdio",
            "env": {
                "AZURE_SEARCH_SERVICE_NAME": config["service_name"],
                "AZURE_SEARCH_API_KEY": config["api_key"],
                "AZURE_SEARCH_INDEX_NAME": config["index_name"],
            },
        },
    }


async def _load_azure_search_tools() -> List[BaseTool]:
    """Async function to load tools from Azure AI Search MCP server."""
    if not MCP_AVAILABLE:
        logger.warning("MCP adapters not available, returning empty tools")
        return []

    config = get_azure_search_mcp_config()

    if not config:
        logger.warning("Azure AI Search MCP not configured, returning empty tools")
        return []

    logger.info("Connecting to Azure AI Search MCP server...")
    logger.info(f"  Service: {config['azure-ai-search']['env']['AZURE_SEARCH_SERVICE_NAME']}")

    try:
        client = MultiServerMCPClient(config)
        tools = await client.get_tools()
        logger.info(f"Loaded {len(tools)} tools from Azure AI Search MCP")
        return tools
    except Exception as e:
        logger.error(f"Failed to load Azure AI Search MCP tools: {e}")
        return []


def get_azure_search_mcp_tools() -> List[BaseTool]:
    """
    Get Azure AI Search MCP tools for use with LangChain agents.

    Returns:
        List of LangChain BaseTool objects:
        - get_index_details: Retrieve index schema and fields
        - query_index: Execute search queries
        - get_knowledge_base: Get knowledge base details
        - retrieve_from_knowledge_base: Execute retrieval operations

    Falls back to SDK-based tools if MCP server is not available.
    """
    # Try MCP first
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(asyncio.run, _load_azure_search_tools())
                tools = future.result()
        else:
            tools = loop.run_until_complete(_load_azure_search_tools())

        if tools:
            return tools
    except RuntimeError:
        try:
            tools = asyncio.run(_load_azure_search_tools())
            if tools:
                return tools
        except Exception as e:
            logger.warning(f"Failed to load MCP tools: {e}")

    # Fall back to SDK-based tools
    logger.info("Falling back to SDK-based Azure Search tools")
    return get_azure_search_sdk_tools()


def get_azure_search_sdk_tools() -> List[BaseTool]:
    """
    Get Azure AI Search tools using the SDK directly.

    This is a fallback when the MCP server is not available.
    """
    if not AZURE_SDK_AVAILABLE:
        logger.warning("Azure Search SDK not available")
        return []

    config = get_azure_search_config()

    if not config["is_configured"]:
        logger.warning("Azure AI Search credentials not configured")
        return []

    endpoint = config["endpoint"]
    index_name = config["index_name"]
    credential = AzureKeyCredential(config["api_key"])

    logger.info(f"Configuring Azure Search SDK with endpoint: {endpoint}")
    logger.info(f"Using index: {index_name}")

    # Create tools using the SDK
    @tool
    def search_code(
        query: str,
        top: int = 10,
        filter_expression: str = None
    ) -> dict:
        """
        Search for code in Azure AI Search index.

        Args:
            query: Search query text
            top: Number of results to return (default 10)
            filter_expression: Optional OData filter expression

        Returns:
            Dict with search results
        """
        try:
            search_client = SearchClient(
                endpoint=endpoint,
                index_name=index_name,
                credential=credential
            )

            results = search_client.search(
                search_text=query,
                top=top,
                filter=filter_expression,
                include_total_count=True
            )

            documents = []
            for result in results:
                documents.append(dict(result))

            return {
                "success": True,
                "total_count": results.get_count(),
                "results": documents[:top],
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    @tool
    def get_index_schema(index_name_param: str = None) -> dict:
        """
        Get the schema of an Azure AI Search index.

        Args:
            index_name_param: Name of the index (uses default if not provided)

        Returns:
            Dict with index schema information
        """
        try:
            index_client = SearchIndexClient(
                endpoint=endpoint,
                credential=credential
            )

            target_index = index_name_param or index_name
            index = index_client.get_index(target_index)

            fields = []
            for field in index.fields:
                fields.append({
                    "name": field.name,
                    "type": str(field.type),
                    "searchable": field.searchable,
                    "filterable": field.filterable,
                    "sortable": field.sortable,
                    "facetable": field.facetable,
                })

            return {
                "success": True,
                "index_name": target_index,
                "fields": fields,
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    @tool
    def index_documents(documents: List[dict]) -> dict:
        """
        Index documents into Azure AI Search.

        Args:
            documents: List of documents to index. Each document must have an 'id' field.

        Returns:
            Dict with indexing results
        """
        try:
            search_client = SearchClient(
                endpoint=endpoint,
                index_name=index_name,
                credential=credential
            )

            result = search_client.upload_documents(documents=documents)

            succeeded = sum(1 for r in result if r.succeeded)
            failed = len(result) - succeeded

            return {
                "success": True,
                "documents_indexed": succeeded,
                "documents_failed": failed,
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    @tool
    def vector_search(
        vector: List[float],
        vector_field: str = "embedding",
        top: int = 10
    ) -> dict:
        """
        Perform vector similarity search.

        Args:
            vector: Query vector (embedding)
            vector_field: Name of the vector field in the index
            top: Number of results to return

        Returns:
            Dict with search results
        """
        try:
            from azure.search.documents.models import VectorizedQuery

            search_client = SearchClient(
                endpoint=endpoint,
                index_name=index_name,
                credential=credential
            )

            vector_query = VectorizedQuery(
                vector=vector,
                k_nearest_neighbors=top,
                fields=vector_field
            )

            results = search_client.search(
                search_text=None,
                vector_queries=[vector_query],
                top=top
            )

            documents = []
            for result in results:
                doc = dict(result)
                doc["@search.score"] = result.get("@search.score", 0)
                documents.append(doc)

            return {
                "success": True,
                "results": documents,
            }
        except ImportError:
            return {
                "success": False,
                "error": "VectorizedQuery not available. Update azure-search-documents.",
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    return [search_code, get_index_schema, index_documents, vector_search]


# List of all Azure Search tools
AZURE_SEARCH_TOOLS = [
    "search_code",
    "get_index_schema",
    "index_documents",
    "vector_search",
]
