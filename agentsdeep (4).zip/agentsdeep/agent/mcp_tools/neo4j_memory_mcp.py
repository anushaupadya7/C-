"""
Neo4j Memory MCP Tools

Loads tools from the mcp-neo4j-memory MCP server using langchain-mcp-adapters.
Based on: https://github.com/neo4j-contrib/mcp-neo4j/tree/main/servers/mcp-neo4j-memory

Tools provided by mcp-neo4j-memory:
- read_graph: Retrieve entire knowledge graph
- search_nodes: Search for nodes by query string
- find_nodes: Find specific nodes by exact names
- create_entities: Create new entities
- delete_entities: Remove entities
- create_relations: Create relationships between entities
- delete_relations: Remove relationships
- add_observations: Add observations to entities
- delete_observations: Remove observations from entities
"""

import os
import asyncio
from typing import List
from langchain_core.tools import BaseTool
from langchain_mcp_adapters.client import MultiServerMCPClient
from loguru import logger


def get_neo4j_memory_mcp_config() -> dict:
    """
    Get MCP server configuration for Neo4j Memory server.

    Environment variables:
    - NEO4J_URI: Database connection URI (default: bolt://localhost:7687)
    - NEO4J_USERNAME: Authentication username (default: neo4j)
    - NEO4J_PASSWORD: Authentication password (default: password)
    - NEO4J_DATABASE: Target database name (default: neo4j)
    """
    neo4j_uri = os.getenv("NEO4J_URI", "bolt://localhost:7687")
    neo4j_username = os.getenv("NEO4J_USERNAME", "neo4j")
    neo4j_password = os.getenv("NEO4J_PASSWORD", "password")
    neo4j_database = os.getenv("NEO4J_DATABASE", "neo4j")

    return {
        "neo4j-memory": {
            "command": "uvx",
            "args": ["mcp-neo4j-memory"],
            "transport": "stdio",
            "env": {
                "NEO4J_URI": neo4j_uri,
                "NEO4J_USERNAME": neo4j_username,
                "NEO4J_PASSWORD": neo4j_password,
                "NEO4J_DATABASE": neo4j_database,
            },
        },
    }


async def _load_memory_tools() -> List[BaseTool]:
    """Async function to load tools from MCP server"""
    config = get_neo4j_memory_mcp_config()

    logger.info("Connecting to Neo4j Memory MCP server...")
    logger.info(f"  URI: {config['neo4j-memory']['env']['NEO4J_URI']}")

    client = MultiServerMCPClient(config)
    tools = await client.get_tools()

    logger.info(f"Loaded {len(tools)} tools from Neo4j Memory MCP")

    return tools


def get_neo4j_memory_mcp_tools() -> List[BaseTool]:
    """
    Get Neo4j Memory MCP tools for use with LangChain agents.

    This function connects to the mcp-neo4j-memory MCP server
    and returns LangChain-compatible tools.

    Returns:
        List of LangChain BaseTool objects:
        - read_graph: Retrieve entire knowledge graph
        - search_nodes: Search for nodes
        - find_nodes: Find specific nodes by name
        - create_entities: Create new entities
        - delete_entities: Remove entities
        - create_relations: Create relationships
        - delete_relations: Remove relationships
        - add_observations: Add facts to entities
        - delete_observations: Remove facts from entities
    """
    # Run async function in sync context
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # If we're already in an async context, create a new task
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(asyncio.run, _load_memory_tools())
                return future.result()
        else:
            return loop.run_until_complete(_load_memory_tools())
    except RuntimeError:
        # No event loop, create one
        return asyncio.run(_load_memory_tools())
