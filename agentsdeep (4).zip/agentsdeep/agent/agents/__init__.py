"""
Deep Agents Module

Provides DeepAgent-based agents for code migration to StencilJS:
- MigrationAgent: Main orchestrator with Neo4j knowledge graph access
- StencilGeneratorSubagent: Specialized code generation subagent
"""

from .migration_agent import create_migration_agent, MigrationAgent
from .config import AgentConfig

__all__ = [
    "create_migration_agent",
    "MigrationAgent",
    "AgentConfig",
]
