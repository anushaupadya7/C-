"""
Agent Configuration

Configuration models for the DeepAgent-based migration system.
"""

import os
from pathlib import Path
from typing import Optional
from pydantic import BaseModel, Field, ConfigDict
from pydantic_settings import BaseSettings, SettingsConfigDict


class Neo4jConfig(BaseModel):
    """Neo4j connection configuration."""

    uri: str = Field(default="bolt://localhost:7687")
    username: str = Field(default="neo4j")
    password: str = Field(default="password")
    database: str = Field(default="neo4j")

    @classmethod
    def from_env(cls) -> "Neo4jConfig":
        return cls(
            uri=os.getenv("NEO4J_URI", "bolt://localhost:7687"),
            username=os.getenv("NEO4J_USERNAME", "neo4j"),
            password=os.getenv("NEO4J_PASSWORD", "password"),
            database=os.getenv("NEO4J_DATABASE", "neo4j"),
        )


class LLMConfig(BaseModel):
    """LLM provider configuration."""

    provider: str = Field(default="azure_openai")
    model: str = Field(default="gpt-4o")
    api_key: str = Field(default="")
    endpoint: str = Field(default="")
    api_version: str = Field(default="2024-02-15-preview")

    @classmethod
    def from_env(cls) -> "LLMConfig":
        # Check for Azure OpenAI first, then OpenAI
        azure_key = os.getenv("AZURE_OPENAI_API_KEY", "")
        openai_key = os.getenv("OPENAI_API_KEY", "")

        if azure_key:
            return cls(
                provider="azure_openai",
                model=os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o"),
                api_key=azure_key,
                endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", ""),
                api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
            )
        else:
            return cls(
                provider="openai",
                model=os.getenv("OPENAI_MODEL", "gpt-4o"),
                api_key=openai_key,
                endpoint="",
            )


class AgentConfig(BaseModel):
    """
    Main configuration for the migration agent system.

    Note: Using BaseModel instead of BaseSettings to avoid auto-loading
    all environment variables. Use from_env() to create from environment.
    """

    # Paths
    working_dir: str = Field(default="C:/", description="Working directory for agent filesystem")
    output_dir: str = Field(default="C:/output", description="Output directory for generated code")
    prompts_dir: str = Field(default="", description="Directory containing prompt .md files")

    # Neo4j
    neo4j: Neo4jConfig = Field(default_factory=Neo4jConfig)

    # LLM
    llm: LLMConfig = Field(default_factory=LLMConfig)

    # Agent settings
    thread_id: str = Field(default="migration-001", description="Thread ID for checkpointing")

    model_config = ConfigDict(extra="ignore")

    @classmethod
    def from_env(cls) -> "AgentConfig":
        """Create configuration from environment variables."""
        # Get the directory where this file is located for prompts
        prompts_dir = str(Path(__file__).parent / "prompts")

        return cls(
            neo4j=Neo4jConfig.from_env(),
            llm=LLMConfig.from_env(),
            prompts_dir=prompts_dir,
            working_dir=os.getenv("AGENT_WORKING_DIR", "C:/"),
            output_dir=os.getenv("AGENT_OUTPUT_DIR", "C:/output"),
            thread_id=os.getenv("AGENT_THREAD_ID", "migration-001"),
        )

    def get_prompt(self, prompt_name: str) -> str:
        """
        Load a prompt from a .md file.

        Args:
            prompt_name: Name of the prompt file (without .md extension)

        Returns:
            Prompt content as string
        """
        prompt_path = Path(self.prompts_dir) / f"{prompt_name}.md"

        if not prompt_path.exists():
            raise FileNotFoundError(f"Prompt file not found: {prompt_path}")

        return prompt_path.read_text(encoding="utf-8")
