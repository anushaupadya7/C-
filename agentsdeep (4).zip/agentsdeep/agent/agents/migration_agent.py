"""
Migration Agent

DeepAgent-based code migration orchestrator that reads from Neo4j knowledge graph
and generates StencilJS code using specialized subagents.
"""

import os
import sys
import asyncio
from typing import Optional, List, Dict, Any
from pathlib import Path

from loguru import logger
from dotenv import load_dotenv

# LangChain imports
from langchain_openai import AzureChatOpenAI, ChatOpenAI
from langchain_core.messages import HumanMessage

# LangGraph imports for memory
from langgraph.checkpoint.memory import MemorySaver
from langgraph.store.memory import InMemoryStore

# DeepAgents imports
from deepagents import create_deep_agent
from deepagents.backends import FilesystemBackend


def _strip_windows_prefix(path: str) -> str:
    """Strip the \\\\?\\ prefix from Windows extended-length paths."""
    if path.startswith("\\\\?\\"):
        return path[4:]
    return path


def _patch_filesystem_backend():
    """
    Patch FilesystemBackend to handle Windows extended-length path prefix (\\\\?\\).
    This fixes the 'path outside root directory' error on Windows.
    """
    if sys.platform != "win32":
        return

    # Store original method
    original_resolve_path = FilesystemBackend._resolve_path

    def patched_resolve_path(self, path: str) -> Path:
        """Patched _resolve_path that handles \\\\?\\ prefix."""
        try:
            return original_resolve_path(self, path)
        except ValueError as e:
            # If we get the "outside root directory" error, try stripping the prefix
            error_msg = str(e)
            if "outside root directory" in error_msg:
                # Get the path from virtual path
                if path.startswith("/"):
                    # Virtual path -> convert to real path
                    real_path = str(Path(self.cwd) / path.lstrip("/"))
                else:
                    real_path = path

                full_path = Path(real_path).resolve()
                root_path = Path(self.cwd).resolve()

                # Strip \\?\ prefix for comparison
                full_str = _strip_windows_prefix(str(full_path))
                root_str = _strip_windows_prefix(str(root_path))

                # Check if path is within root (case-insensitive on Windows)
                if full_str.lower().startswith(root_str.lower()):
                    return full_path

            raise

    FilesystemBackend._resolve_path = patched_resolve_path
    logger.info("Patched FilesystemBackend for Windows extended-length paths")


# Apply the patch on module load
_patch_filesystem_backend()

# Local imports
from .config import AgentConfig
from ..mcp_tools.neo4j_cypher_mcp import get_neo4j_cypher_mcp_tools
from ..mcp_tools.neo4j_memory_mcp import get_neo4j_memory_mcp_tools
from ..mcp_tools.azure_search_mcp import get_azure_search_mcp_tools
from ..mcp_tools.windows_cli_mcp import get_windows_cli_mcp_tools, configure_windows_cli

# Load environment
load_dotenv()


class MigrationAgent:
    """
    Code Migration Agent using DeepAgents framework.

    Features:
    - FilesystemBackend for local file operations
    - InMemoryStore for long-term memory
    - MemorySaver checkpointer for state persistence
    - Neo4j MCP tools for knowledge graph access
    - Azure Search MCP tools for vector search
    - Windows CLI MCP tools for running builds/dev server
    - StencilJS generator subagent for code generation
    - Execution agent subagent for running and fixing code
    """

    def __init__(self, config: Optional[AgentConfig] = None):
        """
        Initialize the Migration Agent.

        Args:
            config: Optional agent configuration
        """
        self.config = config or AgentConfig.from_env()
        self._agent = None
        self._checkpointer = None
        self._store = None
        self._backend = None

        # Ensure working directory exists
        os.makedirs(self.config.working_dir, exist_ok=True)
        os.makedirs(self.config.output_dir, exist_ok=True)

        # Configure Windows CLI with the correct paths
        # Virtual paths /Order.Sample and /output map to C:/Order.Sample and C:/output
        configure_windows_cli(
            working_dir="C:/",
            allowed_paths=[
                "C:/",
                "C:/Order.Sample",
                "C:/output",
            ]
        )

    @property
    def backend(self) -> FilesystemBackend:
        """Get or create the filesystem backend."""
        if self._backend is None:
            # Use resolved path to match how DeepAgents resolves file paths internally
            # This avoids the \\?\ prefix mismatch issue on Windows
            root_dir = str(Path("C:/").resolve())
            logger.info(f"Using root_dir: {root_dir}")
            self._backend = FilesystemBackend(
                root_dir=root_dir,
                virtual_mode=True,  # Enable virtual paths (e.g., /Order.Sample -> C:\Order.Sample)
            )
            logger.info(f"Created FilesystemBackend with root_dir: {root_dir}")
        return self._backend

    @property
    def checkpointer(self) -> MemorySaver:
        """Get or create the in-memory checkpointer."""
        if self._checkpointer is None:
            self._checkpointer = MemorySaver()
            logger.info("Created MemorySaver checkpointer")
        return self._checkpointer

    @property
    def store(self) -> InMemoryStore:
        """Get or create the in-memory store."""
        if self._store is None:
            self._store = InMemoryStore()
            logger.info("Created InMemoryStore")
        return self._store

    def _create_llm(self):
        """Create the LLM based on configuration."""
        llm_config = self.config.llm

        if llm_config.provider == "azure_openai":
            return AzureChatOpenAI(
                azure_endpoint=llm_config.endpoint,
                api_key=llm_config.api_key,
                azure_deployment=llm_config.model,
                api_version=llm_config.api_version,
                temperature=0.1,
            )
        else:
            return ChatOpenAI(
                api_key=llm_config.api_key,
                model=llm_config.model,
                temperature=0.1,
            )

    def _load_mcp_tools(self) -> List:
        """Load all MCP tools (Neo4j, Azure Search, Windows CLI)."""
        tools = []

        # Load Neo4j Cypher tools
        try:
            cypher_tools = get_neo4j_cypher_mcp_tools()
            tools.extend(cypher_tools)
            logger.info(f"Loaded {len(cypher_tools)} Neo4j Cypher tools")
        except Exception as e:
            logger.warning(f"Failed to load Neo4j Cypher tools: {e}")

        # Load Neo4j Memory tools
        try:
            memory_tools = get_neo4j_memory_mcp_tools()
            tools.extend(memory_tools)
            logger.info(f"Loaded {len(memory_tools)} Neo4j Memory tools")
        except Exception as e:
            logger.warning(f"Failed to load Neo4j Memory tools: {e}")

        # Load Azure Search tools
        try:
            search_tools = get_azure_search_mcp_tools()
            tools.extend(search_tools)
            logger.info(f"Loaded {len(search_tools)} Azure Search tools")
        except Exception as e:
            logger.warning(f"Failed to load Azure Search tools: {e}")

        # Load Windows CLI tools
        try:
            cli_tools = get_windows_cli_mcp_tools()
            tools.extend(cli_tools)
            logger.info(f"Loaded {len(cli_tools)} Windows CLI tools")
        except Exception as e:
            logger.warning(f"Failed to load Windows CLI tools: {e}")

        return tools

    def _get_subagents_config(self) -> List[Dict[str, Any]]:
        """Get configuration for all subagents."""
        subagents = []

        # StencilJS Generator Subagent
        try:
            stencil_prompt = self.config.get_prompt("stencil_generator")
        except FileNotFoundError:
            stencil_prompt = "You are a StencilJS code generator. Convert component specifications to StencilJS web components."

        subagents.append({
            "name": "stencil-generator",
            "description": "Specialized subagent for generating StencilJS web component code from specifications. Use this to convert components from other frameworks to StencilJS.",
            "system_prompt": stencil_prompt,
            "tools": [],
        })

        # Logic Validator Subagent
        try:
            validator_prompt = self.config.get_prompt("logic_validator")
        except FileNotFoundError:
            validator_prompt = "You are a logic validation agent that verifies generated code matches source business logic."

        # Load Neo4j and Azure Search tools for validation
        validator_tools = []
        try:
            cypher_tools = get_neo4j_cypher_mcp_tools()
            validator_tools.extend(cypher_tools)
        except Exception as e:
            logger.warning(f"Failed to load Neo4j Cypher tools for validator: {e}")

        try:
            search_tools = get_azure_search_mcp_tools()
            validator_tools.extend(search_tools)
        except Exception as e:
            logger.warning(f"Failed to load Azure Search tools for validator: {e}")

        subagents.append({
            "name": "logic-validator",
            "description": "Logic validation subagent that verifies generated StencilJS code correctly implements the business logic from the source ASP.NET codebase. Uses Neo4j knowledge graph and vector store to compare source logic with generated code. Can request changes from stencil-generator if issues are found.",
            "system_prompt": validator_prompt,
            "tools": validator_tools,
        })

        # NOTE: Execution agent removed - migration is code generation only, no execution

        return subagents

    @property
    def agent(self):
        """Get or create the DeepAgent."""
        if self._agent is None:
            self._agent = self._create_agent()
        return self._agent

    def _create_agent(self):
        """Create the DeepAgent with all configurations."""
        # Load system prompt from markdown file
        try:
            system_prompt = self.config.get_prompt("migration_agent")
        except FileNotFoundError:
            system_prompt = "You are a code migration agent that converts codebases to StencilJS."

        # Load MCP tools
        mcp_tools = self._load_mcp_tools()

        # Get all subagent configurations
        subagents = self._get_subagents_config()

        # Create the model
        model = self._create_llm()

        logger.info("Creating DeepAgent...")
        logger.info(f"  Model: {self.config.llm.model}")
        logger.info(f"  MCP tools: {len(mcp_tools)}")
        logger.info(f"  Subagents: {[s['name'] for s in subagents]}")
        logger.info(f"  Working dir: {self.config.working_dir}")
        logger.info(f"  Output dir: {self.config.output_dir}")

        # Create the deep agent with filesystem backend
        agent = create_deep_agent(
            model=model,
            tools=mcp_tools,
            system_prompt=system_prompt,
            subagents=subagents,
            backend=self.backend,
            checkpointer=self.checkpointer,
            store=self.store,
        )

        return agent

    async def run_async(
        self,
        message: str,
        thread_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Run the agent asynchronously.

        Args:
            message: User message/task
            thread_id: Optional thread ID for checkpointing

        Returns:
            Agent response
        """
        thread_id = thread_id or self.config.thread_id

        config = {
            "configurable": {
                "thread_id": thread_id,
            },
            "recursion_limit": 500,  # Prevent infinite loops
        }

        logger.info(f"Running agent with thread_id: {thread_id}")

        result = await self.agent.ainvoke(
            {"messages": [HumanMessage(content=message)]},
            config=config,
        )

        return result

    def run(
        self,
        message: str,
        thread_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Run the agent synchronously.

        Args:
            message: User message/task
            thread_id: Optional thread ID for checkpointing

        Returns:
            Agent response
        """
        return asyncio.run(self.run_async(message, thread_id))

    async def stream_async(
        self,
        message: str,
        thread_id: Optional[str] = None,
    ):
        """
        Stream agent responses asynchronously.

        Args:
            message: User message/task
            thread_id: Optional thread ID

        Yields:
            Response chunks
        """
        thread_id = thread_id or self.config.thread_id

        config = {
            "configurable": {
                "thread_id": thread_id,
            },
            "recursion_limit": 50,  # Prevent infinite loops
        }

        async for chunk in self.agent.astream(
            {"messages": [HumanMessage(content=message)]},
            config=config,
            stream_mode="values",
        ):
            if "messages" in chunk:
                yield chunk["messages"][-1]

    async def migrate_codebase(
        self,
        source_description: str,
        output_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        High-level method to migrate a codebase to StencilJS.

        Args:
            source_description: Description of the source codebase
            output_path: Output directory for generated StencilJS code

        Returns:
            Migration result
        """
        output_path = output_path or self.config.output_dir

        migration_task = f"""
Migrate the codebase to StencilJS (CODE GENERATION ONLY - NO EXECUTION):

Source: {source_description}
Output: {output_path}

Steps:
1. Query the Neo4j knowledge graph to understand the codebase structure
2. Search Azure AI Search for business logic documentation
3. List all components that need to be migrated
4. For each component:
   a. Extract its props, state, events, and methods
   b. Use the stencil-generator subagent to generate StencilJS code
   c. Write the generated files to {output_path}/src/components/
   d. Generate Node.js API code in {output_path}/api/
5. Generate all config files (package.json, stencil.config.ts, etc.)
6. Report the list of all generated files

DO NOT attempt to run or build the code. Just generate all the files.
Start by querying the knowledge graph for the component structure.
"""

        return await self.run_async(migration_task)

    async def validate_logic(
        self,
        component_name: str,
        output_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Validate that generated code matches source business logic.

        Args:
            component_name: Name of the component to validate
            output_path: Path to the generated StencilJS project

        Returns:
            Validation result
        """
        output_path = output_path or self.config.output_dir

        validate_task = f"""
Use the logic-validator subagent to validate the generated StencilJS code for component '{component_name}':

1. Query Neo4j knowledge graph to get the original business logic for this component:
   - Methods and their implementations
   - Event handlers
   - Data bindings
   - Validation rules
   - Business rules

2. Search Azure AI Search for any additional documentation about this component

3. Read the generated StencilJS file at {output_path}/src/components/{component_name}/

4. Compare the source logic with the generated code:
   - Are all methods implemented?
   - Are event handlers correctly mapped?
   - Is the data binding preserved?
   - Are validation rules complete?

5. Generate a validation report with:
   - What matches correctly
   - What is missing or incorrect
   - Specific fixes needed

6. If issues are found, create a change request for stencil-generator to fix them

Report the validation status: PASSED, NEEDS_CHANGES, or FAILED
"""

        return await self.run_async(validate_task)

    async def run_and_fix(
        self,
        output_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        DISABLED - Execution agent removed. Migration is code generation only.

        To run the generated code manually:
        - cd C:\\output && npm install && npm start (Frontend)
        - cd C:\\output\\api && npm install && npm start (API)
        """
        return {
            "messages": [{
                "content": "Execution disabled. Migration generates code only.\n\n"
                          "To run manually:\n"
                          "1. cd C:\\output && npm install && npm start\n"
                          "2. cd C:\\output\\api && npm install && npm start"
            }]
        }


def create_migration_agent(config: Optional[AgentConfig] = None) -> MigrationAgent:
    """
    Factory function to create a migration agent.

    Args:
        config: Optional configuration

    Returns:
        Configured MigrationAgent instance
    """
    return MigrationAgent(config)


# Convenience function for quick usage
async def migrate(
    task: str,
    config: Optional[AgentConfig] = None,
) -> Dict[str, Any]:
    """
    Quick migration function.

    Args:
        task: Migration task description
        config: Optional configuration

    Returns:
        Agent response
    """
    agent = create_migration_agent(config)
    return await agent.run_async(task)
