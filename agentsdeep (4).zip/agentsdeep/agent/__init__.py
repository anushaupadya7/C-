"""
Agent Module

Provides DeepAgent-based system for code migration to StencilJS:
- MCP Tools: Integration with Neo4j and Azure Search
- Agents: DeepAgent with subagent for StencilJS code generation
"""

from .mcp_tools import (
    get_neo4j_cypher_mcp_tools,
    get_neo4j_memory_mcp_tools,
    get_azure_search_mcp_tools,
)

from .agents import (
    create_migration_agent,
    MigrationAgent,
    AgentConfig,
)

__all__ = [
    # MCP Tools
    "get_neo4j_cypher_mcp_tools",
    "get_neo4j_memory_mcp_tools",
    "get_azure_search_mcp_tools",
    # Agents
    "create_migration_agent",
    "MigrationAgent",
    "AgentConfig",
]
